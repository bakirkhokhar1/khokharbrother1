<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khokhar Brother 1 | Premium Fresh Mart</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;800&family=Plus+Jakarta+Sans:wght@400;500&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-green: #2d6a4f;
            --accent-green: #52b788;
            --light-bg: #f8faf9;
            --text-dark: #1b4332;
            --white: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- 1. Announcement Bar --- */
        .top-bar {
            background: var(--primary-green);
            color: white;
            text-align: center;
            padding: 8px 0;
            font-size: 14px;
            font-weight: 500;
        }

        /* --- 2. Navigation --- */
        header {
            background: var(--white);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 8%;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        }

        .logo {
            font-family: 'Outfit', sans-serif;
            font-size: 26px;
            font-weight: 800;
            color: var(--primary-green);
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: #4a4a4a;
            font-weight: 600;
            transition: 0.3s;
        }

        .nav-links a:hover, .nav-links a.active {
            color: var(--accent-green);
        }

        /* --- 3. Hero Section (Banner) --- */
        .hero {
            height: 500px;
            background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), 
                        url('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1600&q=80');
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            padding: 0 8%;
            margin-bottom: 50px;
        }

        .hero-content {
            color: white;
            max-width: 600px;
        }

        .hero-content h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 56px;
            line-height: 1.1;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 18px;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .btn-main {
            background: var(--accent-green);
            color: white;
            padding: 15px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            display: inline-block;
            transition: 0.3s transform;
            border: none;
            cursor: pointer;
        }

        .btn-main:hover {
            transform: translateY(-3px);
            background: var(--primary-green);
        }

        /* --- 4. Product Cards --- */
        .container {
            padding: 0 8% 80px 8%;
        }

        .section-title {
            font-family: 'Outfit', sans-serif;
            font-size: 32px;
            margin-bottom: 40px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .section-title::after {
            content: "";
            height: 2px;
            background: #ddd;
            flex: 1;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
        }

        .card {
            background: var(--white);
            border-radius: 20px;
            padding: 25px;
            text-align: center;
            transition: 0.3s;
            border: 1px solid #eee;
            position: relative;
        }

        .card:hover {
            box-shadow: 0 20px 40px rgba(0,0,0,0.06);
            transform: translateY(-8px);
        }

        .card img {
            width: 160px;
            height: 160px;
            object-fit: contain;
            margin-bottom: 20px;
        }

        .card h3 {
            font-size: 20px;
            margin-bottom: 8px;
        }

        .card .desc {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .price-tag {
            font-size: 22px;
            font-weight: 800;
            color: var(--primary-green);
            margin-bottom: 20px;
        }

        .add-btn {
            background: #f1f8f5;
            color: var(--primary-green);
            border: 2px solid var(--primary-green);
            width: 100%;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
        }

        .add-btn:hover {
            background: var(--primary-green);
            color: white;
        }

        /* --- 5. Footer --- */
        footer {
            background: #1b4332;
            color: white;
            padding: 60px 8% 30px;
            text-align: center;
        }

        .footer-logo {
            font-family: 'Outfit', sans-serif;
            font-size: 28px;
            margin-bottom: 15px;
        }

        .footer-links {
            margin-bottom: 30px;
        }

        .footer-links a {
            color: #95d5b2;
            margin: 0 15px;
            text-decoration: none;
        }

        .copyright {
            border-top: 1px solid #2d6a4f;
            padding-top: 20px;
            font-size: 14px;
            opacity: 0.7;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 { font-size: 38px; }
            .nav-links { display: none; }
        }
    </style>
</head>
<body>

    <div class="top-bar">🌟 Free Delivery on orders over $20! Shop Now</div>

    <header>
        <a href="#" class="logo">Khokhar Brother 1</a>
        <nav>
            <ul class="nav-links">
                <li><a href="#" class="active">Home</a></li>
                <li><a href="#">Shop</a></li>
                <li><a href="#">Organic</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-content">
            <h1>Farm Fresh <br>Every Single Day</h1>
            <p>We source the finest organic vegetables directly from local farmers to ensure your family gets the best nutrition.</p>
            <button class="btn-main">View Collection</button>
        </div>
    </section>

    <div class="container">
        <h2 class="section-title">Today's Harvest</h2>

        <div class="product-grid">
            <div class="card">
                <img src="https://pngimg.com/uploads/broccoli/broccoli_PNG729.png" alt="Broccoli">
                <h3>Fresh Broccoli</h3>
                <p class="desc">Rich in fiber and vitamins</p>
                <div class="price-tag">$2.99 / kg</div>
                <button class="add-btn" onclick="addToCart('Broccoli')">Add to Cart</button>
            </div>

            <div class="card">
                <img src="https://pngimg.com/uploads/tomato/tomato_PNG12590.png" alt="Tomato">
                <h3>Organic Tomatoes</h3>
                <p class="desc">Sun-ripened and juicy</p>
                <div class="price-tag">$1.50 / kg</div>
                <button class="add-btn" onclick="addToCart('Tomatoes')">Add to Cart</button>
            </div>

            <div class="card">
                <img src="https://pngimg.com/uploads/carrot/carrot_PNG4985.png" alt="Carrot">
                <h3>Crunchy Carrots</h3>
                <p class="desc">Sweet and farm-fresh</p>
                <div class="price-tag">$3.20 / kg</div>
                <button class="add-btn" onclick="addToCart('Carrots')">Add to Cart</button>
            </div>

            <div class="card">
                <img src="https://pngimg.com/uploads/pepper/pepper_PNG1245.png" alt="Pepper">
                <h3>Bell Peppers</h3>
                <p class="desc">Sweet and fiber-rich</p>
                <div class="price-tag">$3.40 / kg</div>
                <button class="add-btn" onclick="addToCart('Peppers')">Add to Cart</button>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-logo">Khokhar Brother 1</div>
        <div class="footer-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Support</a>
        </div>
        <p class="copyright">© 2026 Khokhar Brother 1 Fresh Mart. All Rights Reserved.</p>
    </footer>

    <script>
        function addToCart(item) {
            alert(item + " has been added to your fresh basket! 🛒");
        }
    </script>

</body>
</html>